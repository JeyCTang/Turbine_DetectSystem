# Instruction of the .zip file.

In the .Zip file contains:

1. Source code of Task 2 with .ipynb format
2. Source code of Bonus task with .ipynb format
3. A directory contains the images generated in the Subtask 2.2